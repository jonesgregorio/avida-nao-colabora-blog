import { useEffect, useState, useRef } from 'react'
import {
  Activity, CheckCircle, RefreshCw,
  Loader2, Play, Zap, Database, Sparkles, CreditCard, Bell,
  Shield, ChevronDown, ChevronUp, FileText,
  AlertCircle,
} from 'lucide-react'
import {
  HealthCheckResult, SystemIncident, HealthReport, CheckStatus,
  runQuickHealthCheck, runIntermediateHealthCheck, runFullDiagnostic,
  runSingleCheck, saveHealthCheckResults, createHealthReport,
  detectOrUpdateIncident, resolveIncident, ignoreIncident,
  loadIncidents, loadReports, loadLatestChecks,
} from '../../lib/systemHealth'

// ── Tipos ──────────────────────────────────────────────────────────────────────

type HealthTab = 'overview' | 'auto' | 'diagnostic' | 'reports' | 'incidents' | 'settings'

interface MonitorSettings {
  autoEnabled: boolean
  quickIntervalSec: number
  intermediateIntervalSec: number
  testAI: boolean
  testPayments: boolean
  createIncidents: boolean
  maxAIResponseMs: number
  maxDBResponseMs: number
}

const DEFAULT_SETTINGS: MonitorSettings = {
  autoEnabled: true,
  quickIntervalSec: 30,
  intermediateIntervalSec: 300,
  testAI: true,
  testPayments: true,
  createIncidents: true,
  maxAIResponseMs: 8000,
  maxDBResponseMs: 3000,
}

// ── Helpers visuais ───────────────────────────────────────────────────────────

const STATUS_COLOR: Record<CheckStatus, string> = {
  ok:         'text-emerald-600 bg-emerald-50 border-emerald-200',
  warning:    'text-amber-600 bg-amber-50 border-amber-200',
  error:      'text-red-600 bg-red-50 border-red-200',
  not_tested: 'text-stone-400 bg-stone-50 border-stone-200',
  running:    'text-blue-600 bg-blue-50 border-blue-200',
}

const STATUS_DOT: Record<CheckStatus, string> = {
  ok:         'bg-emerald-500',
  warning:    'bg-amber-400',
  error:      'bg-red-500',
  not_tested: 'bg-stone-300',
  running:    'bg-blue-400 animate-pulse',
}

const STATUS_LABEL: Record<CheckStatus, string> = {
  ok:         'Funcionando',
  warning:    'Atenção',
  error:      'Erro',
  not_tested: 'Não testado',
  running:    'Em teste',
}

const SEVERITY_COLOR: Record<string, string> = {
  info:     'text-stone-500 bg-stone-100',
  low:      'text-blue-600 bg-blue-50',
  medium:   'text-amber-600 bg-amber-50',
  high:     'text-orange-600 bg-orange-50',
  critical: 'text-red-600 bg-red-50',
}

const CATEGORY_ICON: Record<string, typeof Database> = {
  database:        Database,
  auth:            Shield,
  site:            Activity,
  ai:              Sparkles,
  payments:        CreditCard,
  notifications:   Bell,
  personalization: Sparkles,
  diary:           FileText,
  questionnaires:  FileText,
  content:         FileText,
  clinical:        Activity,
  support:         AlertCircle,
  security:        Shield,
}

function StatusBadge({ status }: { status: CheckStatus }) {
  return (
    <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border font-medium ${STATUS_COLOR[status]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${STATUS_DOT[status]}`} />
      {STATUS_LABEL[status]}
    </span>
  )
}

function timeAgo(iso: string): string {
  const diff = Math.round((Date.now() - new Date(iso).getTime()) / 1000)
  if (diff < 60) return `há ${diff}s`
  if (diff < 3600) return `há ${Math.round(diff / 60)}min`
  return `há ${Math.round(diff / 3600)}h`
}

function overallStatus(results: HealthCheckResult[]): CheckStatus {
  if (results.length === 0) return 'not_tested'
  if (results.some(r => r.status === 'error')) return 'error'
  if (results.some(r => r.status === 'warning')) return 'warning'
  if (results.every(r => r.status === 'ok')) return 'ok'
  return 'not_tested'
}

// ── Componente principal ──────────────────────────────────────────────────────

export default function AdminSystemHealth() {
  const [activeTab, setActiveTab] = useState<HealthTab>('overview')
  const [results, setResults] = useState<HealthCheckResult[]>([])
  const [incidents, setIncidents] = useState<SystemIncident[]>([])
  const [reports, setReports] = useState<HealthReport[]>([])
  const [settings, setSettings] = useState<MonitorSettings>(DEFAULT_SETTINGS)
  const [runningKeys, setRunningKeys] = useState<Set<string>>(new Set())
  const [isRunningFull, setIsRunningFull] = useState(false)
  const [isRunningQuick, setIsRunningQuick] = useState(false)
  const [lastQuickAt, setLastQuickAt] = useState<string | null>(null)
  const [toast, setToast] = useState<{ msg: string; err?: boolean } | null>(null)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [incidentFilter, setIncidentFilter] = useState('open')
  const intervalQuickRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const intervalMedRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const isRunningRef = useRef(false)

  function showToast(msg: string, err = false) {
    setToast({ msg, err })
    setTimeout(() => setToast(null), 4000)
  }

  function mergeResults(newOnes: HealthCheckResult[]) {
    setResults(prev => {
      const map = new Map(prev.map(r => [r.checkKey, r]))
      newOnes.forEach(r => map.set(r.checkKey, r))
      return [...map.values()]
    })
  }

  async function doQuickCheck() {
    if (isRunningRef.current) return
    isRunningRef.current = true
    setIsRunningQuick(true)
    try {
      const res = await runQuickHealthCheck()
      mergeResults(res)
      setLastQuickAt(new Date().toISOString())
      await saveHealthCheckResults(res)
      if (settings.createIncidents) {
        for (const r of res.filter(r => r.status === 'error' || r.status === 'warning')) {
          await detectOrUpdateIncident(r)
        }
      }
    } catch (e) {
      showToast('Erro no teste rápido: ' + String(e), true)
    }
    isRunningRef.current = false
    setIsRunningQuick(false)
  }

  async function doIntermediateCheck() {
    if (isRunningRef.current) return
    isRunningRef.current = true
    try {
      const res = await runIntermediateHealthCheck()
      mergeResults(res)
      await saveHealthCheckResults(res)
      if (settings.createIncidents) {
        for (const r of res.filter(r => r.status === 'error' || r.status === 'warning')) {
          await detectOrUpdateIncident(r)
        }
      }
    } catch { /* silencioso */ }
    isRunningRef.current = false
  }

  async function doFullDiagnostic() {
    if (isRunningFull) return
    setIsRunningFull(true)
    isRunningRef.current = true
    try {
      const res = await runFullDiagnostic()
      mergeResults(res)
      setLastQuickAt(new Date().toISOString())
      await saveHealthCheckResults(res)
      await createHealthReport(res, 'full')
      if (settings.createIncidents) {
        for (const r of res.filter(r => r.status === 'error' || r.status === 'warning')) {
          await detectOrUpdateIncident(r)
        }
      }
      await loadIncidents().then(setIncidents)
      await loadReports().then(setReports)
      showToast(`Diagnóstico completo: ${res.filter(r => r.status === 'ok').length} OK, ${res.filter(r => r.status === 'error').length} erros.`)
    } catch (e) {
      showToast('Erro no diagnóstico: ' + String(e), true)
    }
    isRunningRef.current = false
    setIsRunningFull(false)
  }

  async function doSingleCheck(checkKey: string) {
    setRunningKeys(prev => new Set([...prev, checkKey]))
    try {
      const res = await runSingleCheck(checkKey)
      if (res) {
        mergeResults([res])
        await saveHealthCheckResults([res])
        if (settings.createIncidents && (res.status === 'error' || res.status === 'warning')) {
          await detectOrUpdateIncident(res)
        }
        showToast(`${res.checkName}: ${STATUS_LABEL[res.status]}`)
      }
    } catch (e) {
      showToast('Erro: ' + String(e), true)
    }
    setRunningKeys(prev => { const n = new Set(prev); n.delete(checkKey); return n })
  }

  async function doAICheck() {
    await doSingleCheck('ai_provider')
    await doSingleCheck('ai_fallback')
  }

  async function doPaymentsCheck() {
    await doSingleCheck('payments')
  }

  async function handleResolveIncident(id: string) {
    await resolveIncident(id)
    await loadIncidents().then(setIncidents)
    showToast('Incidente marcado como resolvido.')
  }

  async function handleIgnoreIncident(id: string) {
    await ignoreIncident(id)
    await loadIncidents().then(setIncidents)
    showToast('Incidente ignorado.')
  }

  // Carregar dados iniciais
  useEffect(() => {
    Promise.all([
      loadLatestChecks().then(mergeResults),
      loadIncidents().then(setIncidents),
      loadReports().then(setReports),
    ])
    doQuickCheck()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Intervalos automáticos
  useEffect(() => {
    if (!settings.autoEnabled) return
    intervalQuickRef.current = setInterval(() => { void doQuickCheck() }, settings.quickIntervalSec * 1000)
    intervalMedRef.current = setInterval(() => { void doIntermediateCheck() }, settings.intermediateIntervalSec * 1000)
    return () => {
      if (intervalQuickRef.current) clearInterval(intervalQuickRef.current)
      if (intervalMedRef.current) clearInterval(intervalMedRef.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.autoEnabled, settings.quickIntervalSec, settings.intermediateIntervalSec])

  const overall = overallStatus(results)
  const errorCount = results.filter(r => r.status === 'error').length
  const warnCount = results.filter(r => r.status === 'warning').length
  const openIncidents = incidents.filter(i => i.status === 'open' || i.status === 'investigating')

  const TABS: { id: HealthTab; label: string }[] = [
    { id: 'overview',    label: 'Visão geral' },
    { id: 'auto',        label: 'Testes automáticos' },
    { id: 'diagnostic',  label: 'Diagnóstico completo' },
    { id: 'reports',     label: 'Relatórios' },
    { id: 'incidents',   label: `Histórico de erros${openIncidents.length > 0 ? ` (${openIncidents.length})` : ''}` },
    { id: 'settings',    label: 'Configurações' },
  ]

  return (
    <div>
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 text-white text-sm px-4 py-2 rounded-lg shadow-lg ${toast.err ? 'bg-red-600' : 'bg-stone-800'}`}>{toast.msg}</div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-stone-800 flex items-center gap-2">
            <Activity className="w-6 h-6 text-emerald-600" /> Monitoramento do Sistema
          </h1>
          <p className="text-sm text-stone-500 mt-0.5">
            Saúde e diagnóstico das funcionalidades · {settings.autoEnabled ? `Auto a cada ${settings.quickIntervalSec}s` : 'Manual'}
            {lastQuickAt && ` · último teste ${timeAgo(lastQuickAt)}`}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={doAICheck} disabled={runningKeys.has('ai_provider')} className="flex items-center gap-1.5 text-sm border border-stone-200 text-stone-600 px-3 py-2 rounded-lg hover:bg-stone-50 disabled:opacity-50">
            <Sparkles className="w-4 h-4" /> Testar IA
          </button>
          <button onClick={doQuickCheck} disabled={isRunningQuick} className="flex items-center gap-1.5 text-sm border border-stone-200 text-stone-600 px-3 py-2 rounded-lg hover:bg-stone-50 disabled:opacity-50">
            {isRunningQuick ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />} Testar agora
          </button>
          <button onClick={doFullDiagnostic} disabled={isRunningFull} className="flex items-center gap-1.5 text-sm bg-emerald-600 text-white px-3 py-2 rounded-lg hover:bg-emerald-700 disabled:opacity-50">
            {isRunningFull ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            {isRunningFull ? 'Diagnosticando...' : 'Diagnóstico completo'}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-0.5 border-b border-stone-200 mb-5 overflow-x-auto">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} className={`text-sm px-4 py-2.5 border-b-2 transition-colors font-medium whitespace-nowrap ${activeTab === t.id ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-stone-500 hover:text-stone-700'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ── Visão geral ── */}
      {activeTab === 'overview' && (
        <OverviewTab
          results={results} overall={overall} errorCount={errorCount} warnCount={warnCount}
          openIncidents={openIncidents.length} lastQuickAt={lastQuickAt}
          runningKeys={runningKeys} onSingleCheck={doSingleCheck} expanded={expanded} setExpanded={setExpanded}
        />
      )}

      {/* ── Testes automáticos ── */}
      {activeTab === 'auto' && (
        <AutoTab results={results} isRunningQuick={isRunningQuick} onQuickCheck={doQuickCheck} lastAt={lastQuickAt} />
      )}

      {/* ── Diagnóstico completo ── */}
      {activeTab === 'diagnostic' && (
        <DiagnosticTab results={results} isRunning={isRunningFull} onRun={doFullDiagnostic} onAI={doAICheck} onPayments={doPaymentsCheck} runningKeys={runningKeys} onSingleCheck={doSingleCheck} />
      )}

      {/* ── Relatórios ── */}
      {activeTab === 'reports' && (
        <ReportsTab reports={reports} onRefresh={() => loadReports().then(setReports)} />
      )}

      {/* ── Histórico de erros ── */}
      {activeTab === 'incidents' && (
        <IncidentsTab incidents={incidents} filter={incidentFilter} setFilter={setIncidentFilter} onResolve={handleResolveIncident} onIgnore={handleIgnoreIncident} onRetest={doSingleCheck} onRefresh={() => loadIncidents().then(setIncidents)} />
      )}

      {/* ── Configurações ── */}
      {activeTab === 'settings' && (
        <SettingsTab settings={settings} onChange={setSettings} />
      )}
    </div>
  )
}

// ── Aba Visão Geral ───────────────────────────────────────────────────────────

function OverviewTab({ results, overall, errorCount, warnCount, openIncidents, lastQuickAt, runningKeys, onSingleCheck, expanded, setExpanded }: {
  results: HealthCheckResult[]
  overall: CheckStatus
  errorCount: number
  warnCount: number
  openIncidents: number
  lastQuickAt: string | null
  runningKeys: Set<string>
  onSingleCheck: (key: string) => void
  expanded: string | null
  setExpanded: (k: string | null) => void
}) {
  const aiResult = results.find(r => r.checkKey === 'ai_provider')
  const payResult = results.find(r => r.checkKey === 'payments')
  const dbResult = results.find(r => r.checkKey === 'supabase_conn')
  const notifResult = results.find(r => r.checkKey === 'db_notifications')

  const summaryCards = [
    { label: 'Status geral', value: STATUS_LABEL[overall], color: STATUS_DOT[overall], bg: overall === 'ok' ? 'bg-emerald-50' : overall === 'error' ? 'bg-red-50' : 'bg-amber-50' },
    { label: 'Último teste', value: lastQuickAt ? timeAgo(lastQuickAt) : 'nunca', color: 'bg-stone-300', bg: 'bg-stone-50' },
    { label: 'Erros críticos', value: String(errorCount), color: errorCount > 0 ? 'bg-red-500' : 'bg-emerald-500', bg: errorCount > 0 ? 'bg-red-50' : 'bg-emerald-50' },
    { label: 'Alertas', value: String(warnCount), color: warnCount > 0 ? 'bg-amber-400' : 'bg-emerald-500', bg: warnCount > 0 ? 'bg-amber-50' : 'bg-emerald-50' },
    { label: 'IA', value: aiResult ? STATUS_LABEL[aiResult.status] : '—', color: aiResult ? STATUS_DOT[aiResult.status] : 'bg-stone-300', bg: 'bg-stone-50' },
    { label: 'Pagamentos', value: payResult ? STATUS_LABEL[payResult.status] : '—', color: payResult ? STATUS_DOT[payResult.status] : 'bg-stone-300', bg: 'bg-stone-50' },
    { label: 'Banco de dados', value: dbResult ? STATUS_LABEL[dbResult.status] : '—', color: dbResult ? STATUS_DOT[dbResult.status] : 'bg-stone-300', bg: 'bg-stone-50' },
    { label: 'Notificações', value: notifResult ? STATUS_LABEL[notifResult.status] : '—', color: notifResult ? STATUS_DOT[notifResult.status] : 'bg-stone-300', bg: 'bg-stone-50' },
    { label: 'Incidentes abertos', value: String(openIncidents), color: openIncidents > 0 ? 'bg-red-500' : 'bg-emerald-500', bg: openIncidents > 0 ? 'bg-red-50' : 'bg-emerald-50' },
  ]

  return (
    <div className="space-y-5">
      {/* Summary cards */}
      <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-2">
        {summaryCards.map(c => (
          <div key={c.label} className={`${c.bg} rounded-xl p-3 text-center`}>
            <div className={`w-2 h-2 rounded-full ${c.color} mx-auto mb-1`} />
            <p className="text-xs font-bold text-stone-800 truncate">{c.value}</p>
            <p className="text-[10px] text-stone-500 leading-tight">{c.label}</p>
          </div>
        ))}
      </div>

      {/* Tabela de funcionalidades */}
      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
        <div className="px-4 py-3 border-b border-stone-100 flex items-center justify-between">
          <h2 className="font-semibold text-stone-800 text-sm">Funcionalidades</h2>
          <span className="text-xs text-stone-400">{results.length} verificações</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-stone-100 bg-stone-50">
                {['Área', 'Status', 'Última verificação', 'Tempo resp.', 'Ação'].map(h => (
                  <th key={h} className="py-2.5 px-4 text-left text-xs font-semibold text-stone-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {results.length === 0 && (
                <tr><td colSpan={5} className="py-10 text-center text-stone-400 text-sm">Nenhum teste executado ainda.</td></tr>
              )}
              {results.map(r => {
                const Icon = CATEGORY_ICON[r.category] ?? Activity
                const isExpanded = expanded === r.checkKey
                return (
                  <>
                    <tr key={r.checkKey} className="border-b border-stone-100 hover:bg-stone-50/50">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <Icon className="w-3.5 h-3.5 text-stone-400 flex-shrink-0" />
                          <span className="text-sm text-stone-700 font-medium">{r.checkName}</span>
                        </div>
                        {r.errorMessage && <p className="text-xs text-red-500 mt-0.5 pl-5 truncate max-w-xs">{r.errorMessage}</p>}
                      </td>
                      <td className="py-3 px-4"><StatusBadge status={r.status} /></td>
                      <td className="py-3 px-4 text-xs text-stone-500 whitespace-nowrap">agora</td>
                      <td className="py-3 px-4 text-xs text-stone-500 whitespace-nowrap">
                        {r.responseTimeMs != null ? `${r.responseTimeMs}ms` : '—'}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1">
                          <button onClick={() => onSingleCheck(r.checkKey)} className="text-xs text-emerald-600 hover:text-emerald-700 border border-emerald-200 px-2 py-1 rounded-lg">
                            {runningKeys.has(r.checkKey) ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Testar'}
                          </button>
                          {(r.details || r.errorMessage) && (
                            <button onClick={() => setExpanded(isExpanded ? null : r.checkKey)} className="text-xs text-stone-400 hover:text-stone-600 px-1">
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr key={r.checkKey + '-detail'} className="border-b border-stone-100 bg-stone-50">
                        <td colSpan={5} className="px-4 pb-3 pt-1">
                          <div className="bg-white rounded-lg border border-stone-100 p-3 text-xs text-stone-600 font-mono whitespace-pre-wrap max-h-40 overflow-y-auto">
                            {r.errorMessage && <p className="text-red-500 mb-1">Erro: {r.errorMessage}</p>}
                            {r.details && JSON.stringify(r.details, null, 2)}
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// ── Aba Testes Automáticos ────────────────────────────────────────────────────

function AutoTab({ results, isRunningQuick, onQuickCheck, lastAt }: {
  results: HealthCheckResult[]
  isRunningQuick: boolean
  onQuickCheck: () => void
  lastAt: string | null
}) {
  const quickKeys = ['site_public', 'admin_session', 'supabase_conn', 'db_notifications', 'db_pers_tasks', 'db_pers_deliveries', 'db_diary', 'db_articles', 'payments']
  const quickResults = results.filter(r => quickKeys.includes(r.checkKey))
  const interKeys = ['db_questionnaires', 'db_trails', 'db_guidance', 'db_sessions', 'db_reports', 'db_support', 'db_saved', 'rls_personalization', 'drafts_dryrun', 'ai_fallback']
  const interResults = results.filter(r => interKeys.includes(r.checkKey))

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-4">
        <button onClick={onQuickCheck} disabled={isRunningQuick} className="flex items-center gap-2 text-sm bg-stone-800 text-white px-4 py-2 rounded-lg hover:bg-stone-900 disabled:opacity-50">
          {isRunningQuick ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />} Rodar teste rápido agora
        </button>
        {lastAt && <span className="text-xs text-stone-400">Último: {timeAgo(lastAt)}</span>}
      </div>

      <CheckGroup title="Teste rápido (a cada 30s)" subtitle="Leve, não invasivo, sem IA ou pagamentos reais" results={quickResults} />
      <CheckGroup title="Teste intermediário (a cada 5min)" subtitle="Verifica fluxos mais profundos, tabelas clínicas e RLS" results={interResults} />
    </div>
  )
}

function CheckGroup({ title, subtitle, results }: { title: string; subtitle: string; results: HealthCheckResult[] }) {
  return (
    <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
      <div className="px-4 py-3 border-b border-stone-100 bg-stone-50">
        <h3 className="text-sm font-semibold text-stone-800">{title}</h3>
        <p className="text-xs text-stone-400">{subtitle}</p>
      </div>
      <div className="p-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {results.length === 0 && <p className="text-xs text-stone-400 py-4 col-span-3 text-center">Nenhum teste deste grupo executado ainda.</p>}
        {results.map(r => (
          <div key={r.checkKey} className={`flex items-center gap-2 rounded-lg border px-3 py-2 ${STATUS_COLOR[r.status]}`}>
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${STATUS_DOT[r.status]}`} />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{r.checkName}</p>
              {r.responseTimeMs != null && <p className="text-[10px] opacity-70">{r.responseTimeMs}ms</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Aba Diagnóstico ───────────────────────────────────────────────────────────

function DiagnosticTab({ results, isRunning, onRun, onAI, onPayments, runningKeys, onSingleCheck }: {
  results: HealthCheckResult[]
  isRunning: boolean
  onRun: () => void
  onAI: () => void
  onPayments: () => void
  runningKeys: Set<string>
  onSingleCheck: (key: string) => void
}) {
  const categories = [...new Set(results.map(r => r.category))]

  return (
    <div className="space-y-5">
      <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-3">
        <p className="text-sm font-semibold text-stone-800">Diagnóstico completo</p>
        <p className="text-sm text-stone-500">Executa todos os testes, incluindo IA e verificações de segurança. Pode levar até 60 segundos.</p>
        <div className="flex flex-wrap gap-2">
          <button onClick={onRun} disabled={isRunning} className="flex items-center gap-2 bg-emerald-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-emerald-700 disabled:opacity-50">
            {isRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            {isRunning ? 'Diagnosticando...' : 'Rodar diagnóstico completo agora'}
          </button>
          <button onClick={onAI} disabled={runningKeys.has('ai_provider')} className="flex items-center gap-2 border border-stone-200 text-stone-600 text-sm px-3 py-2 rounded-lg hover:bg-stone-100 disabled:opacity-50">
            <Sparkles className="w-4 h-4" /> Testar IA
          </button>
          <button onClick={onPayments} disabled={runningKeys.has('payments')} className="flex items-center gap-2 border border-stone-200 text-stone-600 text-sm px-3 py-2 rounded-lg hover:bg-stone-100 disabled:opacity-50">
            <CreditCard className="w-4 h-4" /> Testar Pagamentos Sandbox
          </button>
        </div>
        <p className="text-xs text-amber-600 bg-amber-50 border border-amber-100 rounded-lg px-2 py-1">Sem cobranças reais · Sem notificações para usuários · Sem criação de dados em produção</p>
      </div>

      {results.length > 0 && categories.map(cat => {
        const catResults = results.filter(r => r.category === cat)
        const Icon = CATEGORY_ICON[cat] ?? Activity
        return (
          <div key={cat} className="bg-white rounded-xl border border-stone-200 overflow-hidden">
            <div className="px-4 py-2.5 border-b border-stone-100 bg-stone-50 flex items-center gap-2">
              <Icon className="w-4 h-4 text-stone-400" />
              <h3 className="text-sm font-semibold text-stone-700 capitalize">{cat}</h3>
              <span className="text-xs text-stone-400 ml-auto">{catResults.length} itens</span>
            </div>
            <div className="divide-y divide-stone-100">
              {catResults.map(r => (
                <div key={r.checkKey} className="flex items-center gap-3 px-4 py-2.5 hover:bg-stone-50/50">
                  <StatusBadge status={r.status} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-stone-700">{r.checkName}</p>
                    {r.errorMessage && <p className="text-xs text-red-500 truncate">{r.errorMessage}</p>}
                  </div>
                  {r.responseTimeMs != null && <span className="text-xs text-stone-400 whitespace-nowrap">{r.responseTimeMs}ms</span>}
                  <button onClick={() => onSingleCheck(r.checkKey)} className="text-xs text-stone-400 hover:text-emerald-600 whitespace-nowrap">
                    {runningKeys.has(r.checkKey) ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Retestar'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── Aba Relatórios ────────────────────────────────────────────────────────────

function ReportsTab({ reports, onRefresh }: { reports: HealthReport[]; onRefresh: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null)
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-stone-700">{reports.length} relatório{reports.length !== 1 ? 's' : ''}</h2>
        <button onClick={onRefresh} className="flex items-center gap-1.5 text-xs border border-stone-200 text-stone-500 px-2 py-1.5 rounded-lg hover:bg-stone-50"><RefreshCw className="w-3 h-3" /> Atualizar</button>
      </div>
      {reports.length === 0 && <p className="text-center py-12 text-stone-400 text-sm">Nenhum relatório gerado ainda. Rode o diagnóstico completo.</p>}
      {reports.map(r => {
        const isExp = expanded === r.id
        const total = r.total_checks
        return (
          <div key={r.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden">
            <button className="w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-stone-50" onClick={() => setExpanded(isExp ? null : r.id)}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-medium text-stone-500 capitalize">{r.report_type}</span>
                  <span className="text-xs text-stone-400">{new Date(r.created_at).toLocaleString('pt-BR')}</span>
                </div>
                <p className="text-sm text-stone-700">{r.summary}</p>
                <div className="flex gap-3 mt-1.5 text-xs">
                  <span className="text-emerald-600">{r.ok_count} OK</span>
                  {r.warning_count > 0 && <span className="text-amber-600">{r.warning_count} alertas</span>}
                  {r.error_count > 0 && <span className="text-red-600">{r.error_count} erros</span>}
                  {r.critical_count > 0 && <span className="text-red-700 font-medium">{r.critical_count} críticos</span>}
                  <span className="text-stone-400">{total} total</span>
                </div>
              </div>
              {isExp ? <ChevronUp className="w-4 h-4 text-stone-400 flex-shrink-0 mt-0.5" /> : <ChevronDown className="w-4 h-4 text-stone-400 flex-shrink-0 mt-0.5" />}
            </button>
            {isExp && Array.isArray((r.details as Record<string, unknown>)?.results) && (
              <div className="border-t border-stone-100 px-4 pb-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 mt-2 max-h-60 overflow-y-auto">
                  {((r.details as Record<string, unknown>).results as Record<string, unknown>[]).map((item) => (
                    <div key={String(item.key)} className={`flex items-center gap-2 text-xs rounded-lg px-2 py-1 border ${STATUS_COLOR[item.status as CheckStatus] ?? ''}`}>
                      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${STATUS_DOT[item.status as CheckStatus] ?? 'bg-stone-300'}`} />
                      <span className="truncate">{String(item.key)}</span>
                      {item.ms != null && <span className="ml-auto text-[10px] opacity-60">{String(item.ms)}ms</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

// ── Aba Incidentes ────────────────────────────────────────────────────────────

function IncidentsTab({ incidents, filter, setFilter, onResolve, onIgnore, onRetest, onRefresh }: {
  incidents: SystemIncident[]
  filter: string
  setFilter: (f: string) => void
  onResolve: (id: string) => void
  onIgnore: (id: string) => void
  onRetest: (key: string) => void
  onRefresh: () => void
}) {
  const filtered = incidents.filter(i => filter === 'all' ? true : i.status === filter)
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        {[['all', 'Todos'], ['open', 'Abertos'], ['investigating', 'Investigando'], ['resolved', 'Resolvidos'], ['ignored', 'Ignorados']].map(([v, l]) => (
          <button key={v} onClick={() => setFilter(v)} className={`text-xs px-3 py-1.5 rounded-lg border ${filter === v ? 'bg-stone-800 text-white border-stone-800' : 'border-stone-200 text-stone-600 hover:bg-stone-50'}`}>{l}</button>
        ))}
        <button onClick={onRefresh} className="ml-auto flex items-center gap-1 text-xs border border-stone-200 text-stone-500 px-2 py-1.5 rounded-lg hover:bg-stone-50"><RefreshCw className="w-3 h-3" /> Atualizar</button>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-14">
          <CheckCircle className="w-10 h-10 mx-auto mb-3 text-emerald-200" />
          <p className="text-sm text-stone-400">Nenhum incidente {filter !== 'all' ? `com status "${filter}"` : ''}.</p>
        </div>
      )}

      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
        {filtered.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-stone-100 bg-stone-50">
                  {['Data', 'Área', 'Título', 'Gravidade', 'Ocorrências', 'Status', 'Ações'].map(h => (
                    <th key={h} className="py-2.5 px-4 text-left text-xs font-semibold text-stone-500 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(inc => (
                  <tr key={inc.id} className="border-b border-stone-100 hover:bg-stone-50/50">
                    <td className="py-3 px-4 text-xs text-stone-500 whitespace-nowrap">{new Date(inc.first_detected_at).toLocaleDateString('pt-BR')}</td>
                    <td className="py-3 px-4 text-xs text-stone-600 font-mono">{inc.check_key ?? '—'}</td>
                    <td className="py-3 px-4">
                      <p className="text-sm text-stone-700 font-medium">{inc.title}</p>
                      {inc.description && <p className="text-xs text-stone-400 truncate max-w-xs">{inc.description}</p>}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${SEVERITY_COLOR[inc.severity] ?? ''}`}>{inc.severity}</span>
                    </td>
                    <td className="py-3 px-4 text-xs text-stone-600">{inc.occurrences}x</td>
                    <td className="py-3 px-4">
                      <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${inc.status === 'open' ? 'bg-red-50 text-red-600 border-red-200' : inc.status === 'resolved' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-stone-100 text-stone-500 border-stone-200'}`}>{inc.status}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        {inc.check_key && (
                          <button onClick={() => onRetest(inc.check_key!)} className="text-xs text-emerald-600 hover:text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded">Retestar</button>
                        )}
                        {inc.status !== 'resolved' && (
                          <button onClick={() => onResolve(inc.id)} className="text-xs text-stone-600 hover:text-stone-800 border border-stone-200 px-1.5 py-0.5 rounded">Resolver</button>
                        )}
                        {inc.status === 'open' && (
                          <button onClick={() => onIgnore(inc.id)} className="text-xs text-stone-400 hover:text-stone-600 px-1.5 py-0.5 rounded">Ignorar</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Aba Configurações ─────────────────────────────────────────────────────────

function SettingsTab({ settings, onChange }: { settings: MonitorSettings; onChange: (s: MonitorSettings) => void }) {
  function set<K extends keyof MonitorSettings>(key: K, value: MonitorSettings[K]) {
    onChange({ ...settings, [key]: value })
  }

  const inputCls = 'px-3 py-2 border border-stone-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-stone-300'

  return (
    <div className="max-w-xl space-y-6">
      <div className="bg-white rounded-xl border border-stone-200 p-5 space-y-4">
        <h2 className="font-semibold text-stone-800">Monitoramento automático</h2>
        <label className="flex items-center justify-between">
          <div>
            <p className="text-sm text-stone-700">Ativar monitoramento automático</p>
            <p className="text-xs text-stone-400">Executa testes em segundo plano enquanto você está no admin</p>
          </div>
          <button onClick={() => set('autoEnabled', !settings.autoEnabled)} className={`w-11 h-6 rounded-full transition-colors relative ${settings.autoEnabled ? 'bg-emerald-500' : 'bg-stone-300'}`}>
            <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${settings.autoEnabled ? 'left-5' : 'left-0.5'}`} />
          </button>
        </label>
        <div className="flex gap-4 flex-wrap">
          <div>
            <label className="text-xs text-stone-500 block mb-1">Intervalo do teste rápido (segundos)</label>
            <input type="number" min={10} max={300} value={settings.quickIntervalSec} onChange={e => set('quickIntervalSec', Number(e.target.value))} className={inputCls + ' w-28'} />
          </div>
          <div>
            <label className="text-xs text-stone-500 block mb-1">Intervalo do teste intermediário (segundos)</label>
            <input type="number" min={60} max={3600} value={settings.intermediateIntervalSec} onChange={e => set('intermediateIntervalSec', Number(e.target.value))} className={inputCls + ' w-28'} />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-stone-200 p-5 space-y-4">
        <h2 className="font-semibold text-stone-800">Testes específicos</h2>
        {([
          ['testAI', 'Ativar teste de IA', 'Testa a Pollinations.ai nos testes intermediários/completos'],
          ['testPayments', 'Ativar verificação de pagamento (sandbox)', 'Verifica configuração, não cria cobranças reais'],
          ['createIncidents', 'Criar incidentes automaticamente ao detectar erros', ''],
        ] as [keyof MonitorSettings, string, string][]).map(([key, label, desc]) => (
          <label key={key} className="flex items-center justify-between">
            <div>
              <p className="text-sm text-stone-700">{label}</p>
              {desc && <p className="text-xs text-stone-400">{desc}</p>}
            </div>
            <button onClick={() => set(key, !settings[key])} className={`w-11 h-6 rounded-full transition-colors relative ${settings[key] ? 'bg-emerald-500' : 'bg-stone-300'}`}>
              <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${settings[key] ? 'left-5' : 'left-0.5'}`} />
            </button>
          </label>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-stone-200 p-5 space-y-4">
        <h2 className="font-semibold text-stone-800">Limites de tempo</h2>
        <div className="flex gap-4 flex-wrap">
          <div>
            <label className="text-xs text-stone-500 block mb-1">Resp. IA máxima (ms)</label>
            <input type="number" min={1000} max={30000} value={settings.maxAIResponseMs} onChange={e => set('maxAIResponseMs', Number(e.target.value))} className={inputCls + ' w-28'} />
          </div>
          <div>
            <label className="text-xs text-stone-500 block mb-1">Resp. banco máxima (ms)</label>
            <input type="number" min={100} max={10000} value={settings.maxDBResponseMs} onChange={e => set('maxDBResponseMs', Number(e.target.value))} className={inputCls + ' w-28'} />
          </div>
        </div>
        <p className="text-xs text-stone-400">Configurações são salvas localmente no navegador por enquanto.</p>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-700">
        <p className="font-medium mb-1">Usuários de teste</p>
        <p className="text-xs">Para diagnósticos completos com dados isolados, configure usuários de teste no banco:</p>
        <ul className="text-xs mt-1 space-y-0.5 font-mono">
          {['teste.gratuito', 'teste.essencial', 'teste.terapeutico', 'teste.plus'].map(u => (
            <li key={u}>• {u}@avida-nao-colabora.com</li>
          ))}
        </ul>
        <p className="text-xs mt-2 text-amber-600">Se não existirem, alguns testes do diagnóstico completo serão ignorados automaticamente.</p>
      </div>
    </div>
  )
}
