// Fonte oficial única dos planos — 3 planos: Gratuito, Essencial, Plus.
// 'therapeutic' / 'therapeutic-plus' são LEGADOS e são normalizados para 'plus'.
// Qualquer alteração nos planos deve ser feita aqui.

export type PlanKey = 'free' | 'essential' | 'plus'

// Normaliza qualquer valor de plano (inclusive legado vindo do banco) para os 3 atuais.
export function normalizePlan(raw: string | null | undefined): PlanKey {
  if (raw === 'essential') return 'essential'
  if (raw === 'plus' || raw === 'therapeutic' || raw === 'therapeutic-plus' || raw === 'therapeutic_plus') return 'plus'
  return 'free'
}

export interface OfficialFeature {
  key: string
  name: string
  category: string
  order: number
  aliases?: string[]
}

export interface OfficialPlan {
  key: PlanKey
  label: string
  price: string
  priceValue: number
  period: string
  tagline: string
  recommended?: boolean
}

// ─── Catálogo completo de recursos oficiais ───────────────────────────────────
// (Alguns recursos do antigo Terapêutico Plus — sessão presencial — saíram do
//  produto; permanecem no catálogo apenas como referência, sem plano que os conceda.)

export const OFFICIAL_FEATURES: OfficialFeature[] = [
  { key: 'articles_free',                             name: 'Artigos gratuitos',                                                                                         category: 'Conteúdo',            order: 1  },
  { key: 'basic_self_assessment',                     name: 'Questionário básico de autoavaliação',                                                                      category: 'Avaliações',          order: 2  },
  { key: 'wellbeing_diary_5_month',                   name: 'Diário de bem-estar com até 5 entradas por mês',                                                            category: 'Diário',              order: 3,  aliases: ['wellbeing_diary_limited', 'diary_monthly_limit_5'] },
  { key: 'simple_mood_checkin',                       name: 'Registro simples de humor',                                                                                 category: 'Diário',              order: 4  },
  { key: 'biweekly_auto_challenges',                  name: 'Práticas guiadas',                                                                                          category: 'Conteúdo',            order: 5  },
  { key: 'limited_history',                           name: 'Histórico limitado',                                                                                        category: 'Histórico',           order: 6  },
  { key: 'ads_enabled',                               name: 'Conteúdos com anúncios',                                                                                    category: 'Anúncios',            order: 7  },
  { key: 'diary_unlimited',                           name: 'Diário ilimitado',                                                                                          category: 'Diário',              order: 8  },
  { key: 'full_history',                              name: 'Histórico completo',                                                                                        category: 'Histórico',           order: 9  },
  { key: 'weekly_assessments',                        name: 'Avaliações semanais',                                                                                       category: 'Avaliações',          order: 10 },
  { key: 'simple_evolution_charts',                   name: 'Gráficos de evolução',                                                                                      category: 'Mapa emocional',      order: 11 },
  { key: 'guided_text_meditations',                   name: 'Meditações guiadas em texto',                                                                               category: 'Conteúdo',            order: 12 },
  { key: 'guided_diary_notes',                        name: 'Notas guiadas no diário',                                                                                   category: 'Diário',              order: 13 },
  { key: 'monthly_pdf_reports',                       name: 'Relatórios em PDF',                                                                                         category: 'Relatórios',          order: 14 },
  { key: 'diary_mood_symptoms_summary',               name: 'Resumo do diário, humor e sintomas',                                                                       category: 'Mapa emocional',      order: 15 },
  { key: 'evolution_highlights_no_clinical_analysis', name: 'Destaques de evolução',                                                                                     category: 'Mapa emocional',      order: 16 },
  { key: 'emotional_exercise_library',                name: 'Biblioteca de exercícios emocionais',                                                                       category: 'Conteúdo',            order: 17 },
  { key: 'no_ads',                                    name: 'Sem anúncios',                                                                                              category: 'Anúncios',            order: 18 },
  { key: 'priority_email_support',                    name: 'Suporte por e-mail prioritário',                                                                            category: 'Suporte',             order: 19 },
  { key: 'deep_questionnaire',                        name: 'Questionário aprofundado',                                                                                  category: 'Avaliações',          order: 20 },
  { key: 'personalized_self_care_plan',               name: 'Plano de autocuidado mensal',                                                                               category: 'Autocuidado',         order: 21 },
  { key: 'advanced_diary',                            name: 'Diário avançado',                                                                                           category: 'Diário',              order: 22 },
  { key: 'extra_emotional_markers',                   name: 'Marcadores extras: sono, medo, compulsão, gatilhos, ansiedade, autoestima e energia',                       category: 'Diário',              order: 23, aliases: ['extra_markers_sleep_depression_fear_compulsion_triggers_anxiety_selfesteem_energy'] },
  { key: 'monthly_comparative_charts',                name: 'Gráficos comparativos mensais',                                                                             category: 'Mapa emocional',      order: 24 },
  { key: 'advanced_monthly_report',                   name: 'Relatório mensal aprofundado',                                                                              category: 'Relatórios',          order: 25 },
  { key: 'personalized_content_recommendations',      name: 'Recomendações personalizadas de conteúdo',                                                                  category: 'Conteúdo',            order: 26 },
  { key: 'weekly_self_care_plan',                     name: 'Plano semanal de autocuidado',                                                                              category: 'Autocuidado',         order: 27 },
  { key: 'early_access_content',                      name: 'Acesso antecipado a novos conteúdos',                                                                       category: 'Conteúdo',            order: 28 },
  { key: 'monthly_message_guidance',                  name: 'Orientação mensal por mensagem',                                                                            category: 'Orientação profissional', order: 29 },
  { key: 'professional_comment_on_monthly_report',    name: 'Comentário profissional mensal',                                                                            category: 'Orientação profissional', order: 30 },
  { key: 'maximum_priority_support',                  name: 'Suporte prioritário máximo',                                                                                category: 'Suporte',             order: 31 },
]

// ─── Mapa de aliases → chave principal ───────────────────────────────────────

export const ALIAS_TO_KEY: Record<string, string> = {}
for (const f of OFFICIAL_FEATURES) {
  if (f.aliases) {
    for (const alias of f.aliases) ALIAS_TO_KEY[alias] = f.key
  }
}

// ─── Hierarquia de herança oficial ───────────────────────────────────────────

export const PLAN_INHERITS_FROM: Partial<Record<PlanKey, PlanKey>> = {
  essential: 'free',
  plus:      'essential',
}

export const INHERIT_LABEL: Partial<Record<PlanKey, string>> = {
  essential: 'Tudo do Gratuito',
  plus:      'Tudo do Essencial',
}

export const DEFAULT_INHERIT: Record<PlanKey, boolean> = {
  free:      false,
  essential: true,
  plus:      true,
}

// ─── Features PRÓPRIAS de cada plano (excluindo herdadas) ────────────────────

const FREE_KEYS = [
  'articles_free', 'basic_self_assessment', 'wellbeing_diary_5_month',
  'simple_mood_checkin', 'biweekly_auto_challenges', 'limited_history', 'ads_enabled',
]
// Essencial absorve o conteúdo/gráficos do antigo Terapêutico (Mapa emocional e Conteúdos guiados completos).
const ESSENTIAL_OWN_KEYS = [
  'diary_unlimited', 'full_history', 'weekly_assessments', 'simple_evolution_charts',
  'guided_text_meditations', 'guided_diary_notes', 'monthly_pdf_reports',
  'diary_mood_symptoms_summary', 'evolution_highlights_no_clinical_analysis',
  'emotional_exercise_library', 'no_ads', 'priority_email_support',
  'deep_questionnaire', 'advanced_diary', 'extra_emotional_markers',
  'monthly_comparative_charts', 'personalized_content_recommendations',
  'weekly_self_care_plan', 'early_access_content',
]
// Plus adiciona autocuidado mensal, relatório aprofundado e orientação profissional.
const PLUS_OWN_KEYS = [
  'personalized_self_care_plan', 'advanced_monthly_report',
  'professional_comment_on_monthly_report', 'monthly_message_guidance',
  'maximum_priority_support',
]

export const OWN_FEATURE_KEYS: Record<PlanKey, string[]> = {
  free:      FREE_KEYS,
  essential: ESSENTIAL_OWN_KEYS,
  plus:      PLUS_OWN_KEYS,
}

// ─── Acesso padrão completo por plano (próprios + herdados) ──────────────────

export const DEFAULT_PLAN_ACCESS: Record<PlanKey, string[]> = {
  free:      FREE_KEYS,
  essential: [...FREE_KEYS, ...ESSENTIAL_OWN_KEYS],
  plus:      [...FREE_KEYS, ...ESSENTIAL_OWN_KEYS, ...PLUS_OWN_KEYS],
}

// ─── Configuração dos planos ──────────────────────────────────────────────────

export const OFFICIAL_PLANS: OfficialPlan[] = [
  { key: 'free',      label: 'Gratuito',  price: 'R$ 0',     priceValue: 0,    period: 'para sempre', tagline: 'Comece a se entender.' },
  { key: 'essential', label: 'Essencial', price: 'R$ 19,90', priceValue: 19.9, period: '/mês',        tagline: 'Acompanhe seus padrões.', recommended: true },
  { key: 'plus',      label: 'Plus',      price: 'R$ 39,90', priceValue: 39.9, period: '/mês',        tagline: 'Receba orientação para agir.' },
]

export const PLAN_KEYS: PlanKey[] = ['free', 'essential', 'plus']

// ─── Hierarquia de acesso (free < essential < plus) ──────────────────────────
// Fonte ÚNICA para comparar planos. Não duplique esta ordem em componentes.

export const PLAN_RANK: Record<PlanKey, number> = { free: 0, essential: 1, plus: 2 }

/**
 * Retorna true se `userPlan` dá acesso a um recurso que exige `requiredPlan`.
 * Ambos são normalizados (legados therapeutic/therapeutic-plus → plus;
 * null/undefined → free). Ordem: free < essential < plus.
 */
export function hasPlanAccess(
  userPlan: string | null | undefined,
  requiredPlan: string | null | undefined,
): boolean {
  return PLAN_RANK[normalizePlan(userPlan)] >= PLAN_RANK[normalizePlan(requiredPlan)]
}

/** Objeto oficial do plano (sempre normalizado — nunca retorna undefined). */
export function getPlan(plan: string | null | undefined): OfficialPlan {
  const key = normalizePlan(plan)
  return OFFICIAL_PLANS.find(p => p.key === key) ?? OFFICIAL_PLANS[0]
}

/** Rótulo de exibição do plano: Gratuito / Essencial / Plus. */
export function getPlanLabel(plan: string | null | undefined): string {
  return getPlan(plan).label
}

/** true se o plano é pago (Essencial ou Plus). */
export function isPaidPlan(plan: string | null | undefined): boolean {
  return normalizePlan(plan) !== 'free'
}

// ─── Lista de exibição PÚBLICA (curta, comercial) — casada com o brief ────────

export const PUBLIC_PLAN_FEATURES: Record<PlanKey, string[]> = {
  free: [
    'Blog aberto', 'Diário emocional básico', 'Questionário inicial', 'Algumas práticas guiadas',
  ],
  essential: [
    'Tudo do Gratuito', 'Diário ilimitado', 'Mapa emocional completo',
    'Histórico e gráficos', 'Conteúdos guiados completos', 'Relatório semanal automático',
  ],
  plus: [
    'Tudo do Essencial', 'Plano de autocuidado mensal', 'Relatório mensal aprofundado',
    'Comentário profissional mensal', 'Orientação mensal por mensagem',
  ],
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Resolve chave de alias para chave principal */
export function resolveKey(key: string): string {
  return ALIAS_TO_KEY[key] ?? key
}

/** Lista pública/comercial de benefícios de um plano. */
export function getPublicPlanBenefits(planKey: PlanKey, inheritEnabled = true): string[] {
  const ownNames = OWN_FEATURE_KEYS[planKey].map(k => OFFICIAL_FEATURES.find(f => f.key === k)!.name)
  const label = INHERIT_LABEL[planKey]
  if (planKey === 'free' || !label || !inheritEnabled) return ownNames
  return [label, ...ownNames]
}

/** Feature keys efetivos de um plano (próprios + herdados em cadeia). */
export function getEffectiveFeatureKeys(planKey: PlanKey, inheritMap?: Record<string, boolean>): string[] {
  const own = [...OWN_FEATURE_KEYS[planKey]]
  const parent = PLAN_INHERITS_FROM[planKey]
  if (parent && ((inheritMap ?? DEFAULT_INHERIT)[planKey] ?? DEFAULT_INHERIT[planKey])) {
    return [...getEffectiveFeatureKeys(parent, inheritMap), ...own]
  }
  return own
}

/** Constrói AccessMap { planKey: { featureKey: boolean } } com base em herança */
export function buildDefaultAccessMap(inheritMap?: Record<string, boolean>): Record<string, Record<string, boolean>> {
  const result: Record<string, Record<string, boolean>> = {}
  for (const planKey of PLAN_KEYS) {
    result[planKey] = {}
    const effective = new Set(getEffectiveFeatureKeys(planKey, inheritMap))
    for (const f of OFFICIAL_FEATURES) {
      result[planKey][f.key] = effective.has(f.key)
    }
  }
  return result
}

/** Para cada plano, retorna quais features são herdadas (vêm do parent). */
export function getInheritedFeatureKeys(planKey: PlanKey, inheritMap?: Record<string, boolean>): string[] {
  const parent = PLAN_INHERITS_FROM[planKey]
  if (!parent) return []
  if (!((inheritMap ?? DEFAULT_INHERIT)[planKey] ?? DEFAULT_INHERIT[planKey])) return []
  return getEffectiveFeatureKeys(parent, inheritMap)
}
